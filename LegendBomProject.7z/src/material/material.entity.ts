import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('material')
export class material {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ nullable: true })
    materialNumber?: number;

    @Column({ nullable: true })
    altBOM?: number;

    @Column({ nullable: true })
    baseQty?: number;

    @Column({ nullable: true })
    UOM?: string;

    @Column({ nullable: true })
    plant?: string;

    @Column({ nullable: true })
    createdBy?: string;

    @Column({ nullable: true })
    Status?: string;

    @Column({ nullable: true })
    ApprovedBy?: string;

    @Column({ nullable: true })
    DeletedMaterial?: string;
}
